#!/usr/bin/env bash

set -u
set -o pipefail

# ===== 入力ファイル =====
RECEPTOR="receptor/4DFR_chainA_raw.pdb"
LIGAND="ligand/MTX_pH7_4.sdf"
CRYSTAL="ligand/4DFR_MTX_A_crystal.sdf"

# ===== 出力先 =====
ROOT="robustness_4DFR"
RUN_DIR="${ROOT}/runs"
LOG_DIR="${ROOT}/logs"
SUMMARY="${ROOT}/aws_run_summary.csv"

# ===== 実験条件 =====
SEED_START=1
SEED_END=20
EXHAUSTIVENESS_VALUES=(8 16 32)
NUM_MODES=9
AUTOBOX_ADD=4

mkdir -p "$RUN_DIR" "$LOG_DIR"

# 入力確認
for file in "$RECEPTOR" "$LIGAND" "$CRYSTAL"; do
    if [[ ! -f "$file" ]]; then
        echo "ERROR: 入力ファイルがありません: $file" >&2
        exit 1
    fi
done

if ! command -v smina >/dev/null 2>&1; then
    echo "ERROR: sminaが見つかりません" >&2
    exit 1
fi

echo "seed,exhaustiveness,elapsed_seconds,status,output_file,log_file" \
    > "$SUMMARY"

total_runs=$(( (SEED_END - SEED_START + 1) * ${#EXHAUSTIVENESS_VALUES[@]} ))
current_run=0

for exhaustiveness in "${EXHAUSTIVENESS_VALUES[@]}"; do
    for seed in $(seq "$SEED_START" "$SEED_END"); do
        current_run=$((current_run + 1))

        tag="exh${exhaustiveness}_seed${seed}"
        output="${RUN_DIR}/${tag}.sdf"
        log="${LOG_DIR}/${tag}.log"

        echo
        echo "=================================================="
        echo "Run ${current_run}/${total_runs}"
        echo "seed=${seed}, exhaustiveness=${exhaustiveness}"
        echo "=================================================="

        start_time=$(date +%s)

        if smina \
            --receptor "$RECEPTOR" \
            --ligand "$LIGAND" \
            --autobox_ligand "$CRYSTAL" \
            --autobox_add "$AUTOBOX_ADD" \
            --exhaustiveness "$exhaustiveness" \
            --num_modes "$NUM_MODES" \
            --seed "$seed" \
            --out "$output" \
            --log "$log"
        then
            status="success"
        else
            status="failed"
        fi

        end_time=$(date +%s)
        elapsed=$((end_time - start_time))

        echo "${seed},${exhaustiveness},${elapsed},${status},${output},${log}" \
            >> "$SUMMARY"

        echo "Finished: ${tag}, status=${status}, ${elapsed}s"
    done
done

echo
echo "全計算終了"
echo "Summary: $SUMMARY"
